<?php
include "db/db_con.php";
include "controllers/controller_productos.php";
?>